import 'package:flutter/material.dart';

List<Map<String,dynamic>> resumelist=[
  {
    "menu_name":"contact Info",
    "icon":Icons.quick_contacts_mail_outlined,
    "route_name":"contact_info",
  },
  {
    "menu_name":"carrier obj",
    "icon":Icons.business_center,
    "route_name":"carrier_obj",
  },
  {
    "menu_name":"  Personal Detail",
    "icon":Icons.person_outline,
    "route_name":"personal_detail",
  },
  {
    "menu_name":"Education",
    "icon":Icons.school,
    "route_name":"education",

  },
  {
    "menu_name":"Experience",
    "icon":Icons.manage_accounts,
    "route_name":"experience",
  },
  {
    "menu_name":"Technical_Skill",
    "icon":Icons.workspace_premium,
    "route_name":"technical_skill",
  },
  {
    "menu_name":"project",
    "icon":Icons.plagiarism_rounded,
    "route_name":"project",
  },
  {
    "menu_name":"interest/hobbies",
    "icon":Icons.library_books,
    "route_name":"hobbies",
  },
  {
    "menu_name":"Achievement",
    "icon":Icons.redeem,
    "route_name":"achievement",
  },
  {
    "menu_name":"Refrences",
    "icon":Icons.handshake,
    "route_name":"refrences",
  },
  {
    "menu_name":"Declaration",
    "icon":Icons.description,
    "route_name":"declaration",
  },

];