import 'package:flutter/material.dart';
import 'package:resume_bilder/resume/util.dart';

class contact_info extends StatefulWidget {
  const contact_info({super.key});

  @override
  State<contact_info> createState() => _contact_infoState();
}

int page = 0;

class _contact_infoState extends State<contact_info> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "contact_Info",
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.w700, fontSize: 25),
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextButton(
                    onPressed: () {
                      page = 0;
                      setState(() {});
                    },
                    child: Text(
                      "contacts",
                      style: TextStyle(color: Colors.black, fontSize: 20),
                    )),
              ),
              Expanded(
                child: TextButton(
                    onPressed: () {
                      page = 1;
                      setState(() {});
                    },
                    child: Text(
                      "photos",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          textBaseline: TextBaseline.alphabetic),
                    )),
              ),
            ],
          ),
          Expanded(
            child: IndexedStack(
              index: page,
              children: [
                contact(),
                photos(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class contact extends StatefulWidget {
  const contact({super.key});

  @override
  State<contact> createState() => _contactState();
}

class _contactState extends State<contact> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 18.0,right: 18),
      child: Container(
        height: 400,
        width: 400,
        margin: EdgeInsets.only(top: 40),

        decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  color: Colors.grey, blurRadius: 10, offset: Offset(0.5, 0.5))
            ],
            borderRadius: BorderRadius.all(Radius.circular(10))),
        child: Column(
          children: [
            Row(
              children: [
                Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Icon(
                      Icons.person,
                      size: 30,
                    )),
                SizedBox(width: 10),
                Expanded(
                    child: TextField(
                  decoration: InputDecoration(hintText: "Enter user Name"),
                )),
                SizedBox(
                  width: 20,
                ),
              ],
            ),
            Row(
              children: [
                Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Icon(
                      Icons.mail,
                      size: 30,
                    )),
                SizedBox(width: 10),
                Expanded(
                    child: TextField(
                  decoration: InputDecoration(hintText: "Email"),
                )),
                SizedBox(
                  width: 20,
                ),
              ],
            ),
            Row(
              children: [
                Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Icon(
                      Icons.phone_android,
                      size: 30,
                    )),
                SizedBox(width: 10),
                Expanded(
                    child: TextField(
                  decoration: InputDecoration(hintText: "Phone"),
                )),
                SizedBox(
                  width: 20,
                ),
              ],
            ),
            Row(
              children: [
                Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Icon(
                      Icons.location_on_sharp,
                      size: 30,
                    )),
                SizedBox(width: 10),
                Expanded(
                    child: TextField(
                  decoration: InputDecoration(hintText: "user Address line:1"),
                )),
                SizedBox(
                  width: 20,
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(left: 70.0, top: 10, right: 20),
              child: TextField(
                decoration: InputDecoration(hintText: "user Address line:2"),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 70.0, right: 20, top: 10),
              child: TextField(
                decoration: InputDecoration(hintText: "user Address line:3"),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class photos extends StatefulWidget {
  const photos({super.key});

  @override
  State<photos> createState() => _photosState();
}

class _photosState extends State<photos> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: SingleChildScrollView(scrollDirection: Axis.vertical,
        child: Container(
          height: 300,
          width: 380,
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 30),
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.grey, offset: Offset(0.5, 0.5), blurRadius: 10)
              ],
              borderRadius: BorderRadius.all(Radius.circular(10))),
          child: Center(
              child: Stack(
            children: [
              CircleAvatar(
                radius: 80,
                backgroundColor: Colors.grey,
                child: Text(
                  "ADD",
                  style: TextStyle(fontSize: 20),
                ),
              ),
              Positioned(
                  bottom: 10,
                  right: 20,
                  child: Icon(
                    Icons.add_circle,
                  )),
            ],
          )),
        ),
      ),
    );
  }
}
