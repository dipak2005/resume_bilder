import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:resume_bilder/resume/achievement.dart';
import 'package:resume_bilder/resume/carrier_obj.dart';
import 'package:resume_bilder/resume/contact_info.dart';
import 'package:resume_bilder/resume/declaration.dart';
import 'package:resume_bilder/resume/education.dart';
import 'package:resume_bilder/resume/experience.dart';
import 'package:resume_bilder/resume/project.dart';
import 'package:resume_bilder/resume/homepage.dart';
import 'package:resume_bilder/resume/personal_detail.dart';
import 'package:resume_bilder/resume/hobbies.dart';
import 'package:resume_bilder/resume/refrences.dart';
import 'package:resume_bilder/resume/resume_workspace.dart';
import 'package:resume_bilder/resume/splash_screen.dart';
import 'package:resume_bilder/resume/technical_skill.dart';

void main() {
  runApp(myapp());
}

class myapp extends StatefulWidget {
  const myapp({super.key});

  @override
  State<myapp> createState() => _myappState();
}

class _myappState extends State<myapp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.fallback(useMaterial3: true),
      initialRoute: "splash_screen",
      routes: {
        "splash_screen": (context) => splash_screen(),
        "homepage": (context) => homepage(),
        "resume_workspace": (context) => const resume_workspace(),
        "contact_info": (context) => const contact_info(),
        "carrier_obj": (context) => carrier_obj(),
        "achievement": (context) => achievement(),
        "personal_detail": (context) => personal_detail(),
        "declaration": (context) => declaration(),
        "education": (context) => education(),
        "experience": (context) => experience(),
        "technical_skill": (context) => technical_skill(),
        "hobbies": (context) => hobbies(),
        "project": (context) => project(),
        "refrences": (context) => refrences(),
      },
      // onUnknownRoute: (settings) {
      //   return MaterialPageRoute(
      //     builder: (context) {
      //       return Scaffold(
      //         appBar: AppBar(
      //           title: Text(
      //             "contactInfo",
      //             style: TextStyle(
      //                 color: Colors.black,
      //                 fontSize: 25,
      //                 fontWeight: FontWeight.w700),
      //           ),
      //         ),
      //       );
      //     },
      //   );
      // },
    );
  }
}
